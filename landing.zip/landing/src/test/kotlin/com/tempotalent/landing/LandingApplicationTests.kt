package com.tempotalent.landing

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class LandingApplicationTests {

	@Test
	fun contextLoads() {
	}

}
